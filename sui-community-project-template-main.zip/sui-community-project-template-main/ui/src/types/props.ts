export interface RefreshProps {
  refreshKey: number;
  setRefreshKey: (key: number) => void;
}
